#include "SDL.h"   /* All SDL App's need this */
#include <stdio.h>
#include <unistd.h>

/* Globals */

SDL_Surface *sdl_screen;


void sdl_setpalette(void) {
   struct { Uint8 R,G,B; } Palette[16] =
   {
     {0x00,0x00,0x00},{0x00,0x00,0x00},{0x20,0xC0,0x20},{0x60,0xE0,0x60},
     {0x20,0x20,0xE0},{0x40,0x60,0xE0},{0xA0,0x20,0x20},{0x40,0xC0,0xE0},
     {0xE0,0x20,0x20},{0xE0,0x60,0x60},{0xC0,0xC0,0x20},{0xC0,0xC0,0x80},
     {0x20,0x80,0x20},{0xC0,0x40,0xA0},{0xA0,0xA0,0xA0},{0xE0,0xE0,0xE0}
   };
   SDL_Color colours[16];
   int i;

   printf("set_palette\n");
   for (i=0;i<16 ;i++) {
      colours[i].r = Palette[i].R;
      colours[i].g = Palette[i].G;
      colours[i].b = Palette[i].B;
   }
   if ((SDL_SetColors(sdl_screen, colours, 0, 16))==1) {
      printf("colours set OK\n");
   }
}


int init_sdl(void) {
    int x;
    Uint32 y;
    Uint8  *buffer;
    
    printf("Initializing SDL.\n");
    
    /* Initialize defaults, Video and Audio */
    if((SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO)==-1)) { 
        printf("Could not initialize SDL: %s.\n", SDL_GetError());
        exit(-1);
    }
    atexit(SDL_Quit);

    printf("SDL initialized.\n");

    sdl_screen = SDL_SetVideoMode(512, 400, 16, SDL_SWSURFACE);
    if ( sdl_screen == NULL ) {
        fprintf(stderr, "Couldn't set 512x400x16 video mode: %s\n",
                        SDL_GetError());
        return(1);
    }
    SDL_WM_SetCaption("Hello there","Hello there");

    //sdl_setpalette();

    return(0);
}

int main(int argc, char **argv) {

   Uint32 yellow;
   Uint8 *p;
   int x;

   init_sdl();
   yellow = SDL_MapRGB(sdl_screen->format, 0xff, 0xff, 0x00);
   SDL_LockSurface(sdl_screen);
   for (x=0;x<100;x++) {
      p = (Uint8 *)sdl_screen->pixels + x * sdl_screen->pitch + x * 2;
      *(Uint16 *)p = yellow;
   }
   SDL_UnlockSurface(sdl_screen);
   SDL_UpdateRect(sdl_screen,0,0,0,0);

   sleep(5);

   SDL_Quit();


}
