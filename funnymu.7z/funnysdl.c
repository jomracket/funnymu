#include "SDL.h"   /* All SDL App's need this */
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include "funny.h"
#include "funnysdl.h"

/* Globals */
#define PLAYBUF_SIZE 1024
static Uint8 playbuf[PLAYBUF_SIZE];
static volatile int snd_read = 0;
static SDL_AudioSpec spec;

int SaveCPU  = 1;               /* 1 = freeze when focus out */
int UseSHM   = 1;               /* 1 = use MITSHM            */
int UseSound = 1;               /* 1 = use sound             */

SDL_Surface *sdl_screen;
Uint32  sdl_colours[16];
char sdl_title[]="FunnyMu v0.43";

#define WIDTH  256
#define HEIGHT 208


void sdl_setpalette(void) {
   struct { Uint8 R,G,B; } Palette[16] =
   {
     {0x00,0x00,0x00},{0x00,0x00,0x00},{0x20,0xC0,0x20},{0x60,0xE0,0x60},
     {0x20,0x20,0xE0},{0x40,0x60,0xE0},{0xA0,0x20,0x20},{0x40,0xC0,0xE0},
     {0xE0,0x20,0x20},{0xE0,0x60,0x60},{0xC0,0xC0,0x20},{0xC0,0xC0,0x80},
     {0x20,0x80,0x20},{0xC0,0x40,0xA0},{0xA0,0xA0,0xA0},{0xE0,0xE0,0xE0}
   };
   int i;

   printf("set_palette\n");
   for (i=0;i<16;i++) {
      sdl_colours[i] = SDL_MapRGB(sdl_screen->format, 
        Palette[i].R, Palette[i].G, Palette[i].B);
      sdl_colours[i]+=sdl_colours[i]<<16;
   }
}

static void _sdl_snd_callback(void *udata, Uint8 *stream, int len)
{
  int i;
  for(i = 0; i < len; ++i)
    {
      if(snd_read == PLAYBUF_SIZE) {
         SN76496Update(0,playbuf,PLAYBUF_SIZE/2);
         snd_read=0;
      }
#ifndef LSB_FIRST
      if (i & 1) {
         stream[i-1] = (playbuf[snd_read++]);
      } else {
         stream[i+1] = (playbuf[snd_read++]);
      }
#else
      stream[i] = (playbuf[snd_read++] -0x6000)>>1;
#endif
    }
}

int sound_init(void) {

   SDL_AudioSpec wanted;

   wanted.freq = 22050;
   wanted.format = AUDIO_S16;
   wanted.channels = 1;
   wanted.samples = 256;
   wanted.callback = _sdl_snd_callback;
   wanted.userdata = NULL;

   if(SDL_OpenAudio(&wanted, &spec) < 0)
   {
      fprintf(stderr, "sdl: Couldn't open audio: %s!\n", SDL_GetError());
      return 0;
   } else {
      printf("sdl audio opened\n");
   }

   if(spec.channels != 1)
   {
      fprintf(stderr, "sdl: Couldn't get mono audio format!\n");
      SDL_CloseAudio();
   }

   SN76496Init(0,VDP_CLOCK/15,0,spec.freq);

   printf("start sdl audio\n");
   SDL_PauseAudio(0);
   return(0);

}


int init_sdl(void) {
    int x;
    Uint32 y;
    Uint8  *buffer;
    
    printf("Initializing SDL.\n");
    
    /* Initialize defaults, Video and Audio */
    if((SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO)==-1)) { 
        printf("Could not initialize SDL: %s.\n", SDL_GetError());
        exit(-1);
    }
    atexit(SDL_Quit);

    printf("SDL initialized.\n");

    sound_init();

    sdl_screen = SDL_SetVideoMode(512, 420, 16, SDL_HWSURFACE);
    if ( sdl_screen == NULL ) {
        fprintf(stderr, "Couldn't set 512x420x16 video mode: %s\n",
                        SDL_GetError());
        return(1);
    }
    sdl_setpalette();
    SDL_WM_SetCaption(sdl_title,sdl_title);

    return(0);
}

Uint32 sdl_getticks(void) {
   return(SDL_GetTicks());
}


/** This function is called on signals ***********************/
static void OnBreak(int Arg) { ExitNow=1;signal(Arg,OnBreak); }

/** InitMachine() ********************************************/
/** Allocate resources needed by Unix/X-dependent code.     **/
/*************************************************************/
int InitMachine(void)
{

  init_sdl();

  /* Catch all signals */
#ifndef WIN32
  signal(SIGHUP,OnBreak);signal(SIGINT,OnBreak);
  signal(SIGQUIT,OnBreak);signal(SIGTERM,OnBreak);
#endif
  return(1);
}

/** TrashMachine() *******************************************/
/** Deallocate all resources taken by InitMachine().        **/
/*************************************************************/
void TrashMachine(void)
{
  unsigned long L;
  int J;

  if(Verbose) printf("Shutting down...\n");


}

void Joysticks(void)
{
  SDL_Event sdl_event;

  if(SDL_PollEvent(&sdl_event))
  {
    if(sdl_event.type==SDL_KEYDOWN) {
      switch(sdl_event.key.keysym.sym)
      {
        case SDLK_F2:  LogSnd=!LogSnd;break;
        case SDLK_ESCAPE: Reset6502(&CPU); break;

        case SDLK_F12: ExitNow=1;break;
#ifdef DEBUG
        case SDLK_F1:  CPU.Trace=!CPU.Trace;break;
#endif

        case SDLK_z: KEYTBL[13]&=0xf5; break;
        case SDLK_a: KEYTBL[13]&=0xee; break;
        case SDLK_q: KEYTBL[13]&=0xe7; break;
        case SDLK_2: KEYTBL[13]&=0xcf; break;
        case SDLK_x: KEYTBL[13]&=0xed; break;
        case SDLK_s: KEYTBL[13]&=0xde; break;
        case SDLK_w: KEYTBL[13]&=0xf3; break;
        case SDLK_3: KEYTBL[13]&=0x9f; break;
        case SDLK_c: KEYTBL[13]&=0xdd; break;
        case SDLK_d: KEYTBL[13]&=0xbe; break;
        case SDLK_e: KEYTBL[13]&=0xeb; break;
        case SDLK_4: KEYTBL[13]&=0xd7; break;
        case SDLK_v: KEYTBL[13]&=0xbd; break;
        case SDLK_f: KEYTBL[13]&=0xfc; break;
        case SDLK_r: KEYTBL[13]&=0xdb; break;
        case SDLK_5: KEYTBL[13]&=0xb7; break;
        case SDLK_b: KEYTBL[13]&=0xf9; break;
        case SDLK_g: KEYTBL[13]&=0xfa; break;
        case SDLK_t: KEYTBL[13]&=0xbb; break;
        case SDLK_6: KEYTBL[13]&=0xaf; break;
        case SDLK_1: KEYTBL[14]&=0xf3; break;
        case SDLK_BACKSPACE: KEYTBL[13]&=0xf6; break;

        case SDLK_LCTRL:  KEYTBL[7]&=0x7f; break;
        case SDLK_LSHIFT: KEYTBL[13]&=0x7f; break;
        case SDLK_RSHIFT: KEYTBL[14]&=0x7f; break;
        case SDLK_QUOTE: KEYTBL[14]&=0x7f; break;
        case SDLK_TAB: KEYTBL[11]&=0x7f; break;

        case SDLK_COLON: KEYTBL[7]&=0xf5; break;
        case SDLK_p: KEYTBL[7]&=0xee; break;
        case SDLK_SEMICOLON: KEYTBL[7]&=0xe7; break;
        case SDLK_SLASH: KEYTBL[7]&=0xcf; break;
        case SDLK_0: KEYTBL[7]&=0xed; break;
        case SDLK_o: KEYTBL[7]&=0xde; break;
        case SDLK_l: KEYTBL[7]&=0xf3; break;
        case SDLK_PERIOD: KEYTBL[7]&=0x9f; break;
        case SDLK_9: KEYTBL[7]&=0xdd; break;
        case SDLK_i: KEYTBL[7]&=0xbe; break;
        case SDLK_k: KEYTBL[7]&=0xeb; break;
        case SDLK_COMMA: KEYTBL[7]&=0xd7; break;
        case SDLK_8: KEYTBL[7]&=0xbd; break;
        case SDLK_u: KEYTBL[7]&=0xfc; break;
        case SDLK_j: KEYTBL[7]&=0xdb; break;
        case SDLK_m: KEYTBL[7]&=0xb7; break;
        case SDLK_7: KEYTBL[7]&=0xf9; break;
        case SDLK_y: KEYTBL[7]&=0xfa; break;
        case SDLK_h: KEYTBL[7]&=0xbb; break;
        case SDLK_n: KEYTBL[7]&=0xaf; break;
        case SDLK_RETURN: KEYTBL[7]&=0xf6; break;
        case SDLK_SPACE: KEYTBL[11]&=0xf3; break;

        case SDLK_DOWN:   KEYTBL[14]&=0xfd;break;
        case SDLK_UP:     KEYTBL[14]&=0xf7;break;
        case SDLK_LEFT:   KEYTBL[14]&=0xdf;break;
        case SDLK_RIGHT:  KEYTBL[14]&=0xfb;break;


      }
    }
    if (sdl_event.type==SDL_KEYUP) {
      switch(sdl_event.key.keysym.sym)
      {
        case SDLK_z: KEYTBL[13]|=0x0a; break;
        case SDLK_a: KEYTBL[13]|=0x11; break;
        case SDLK_q: KEYTBL[13]|=0x18; break;
        case SDLK_2: KEYTBL[13]|=0x30; break;
        case SDLK_x: KEYTBL[13]|=0x12; break;
        case SDLK_s: KEYTBL[13]|=0x21; break;
        case SDLK_w: KEYTBL[13]|=0x0c; break;
        case SDLK_3: KEYTBL[13]|=0x60; break;
        case SDLK_c: KEYTBL[13]|=0x22; break;
        case SDLK_d: KEYTBL[13]|=0x41; break;
        case SDLK_e: KEYTBL[13]|=0x14; break;
        case SDLK_4: KEYTBL[13]|=0x28; break;
        case SDLK_v: KEYTBL[13]|=0x42; break;
        case SDLK_f: KEYTBL[13]|=0x03; break;
        case SDLK_r: KEYTBL[13]|=0x24; break;
        case SDLK_5: KEYTBL[13]|=0x48; break;
        case SDLK_b: KEYTBL[13]|=0x06; break;
        case SDLK_g: KEYTBL[13]|=0x05; break;
        case SDLK_t: KEYTBL[13]|=0x44; break;
        case SDLK_6: KEYTBL[13]|=0x50; break;
        case SDLK_1: KEYTBL[14]|=0x0c; break;
        case SDLK_BACKSPACE: KEYTBL[13]|=0x09; break;

        case SDLK_COLON: KEYTBL[7]|=0x0a; break;
        case SDLK_p: KEYTBL[7]|=0x11; break;
        case SDLK_SEMICOLON: KEYTBL[7]|=0x18; break;
        case SDLK_SLASH: KEYTBL[7]|=0x30; break;
        case SDLK_0: KEYTBL[7]|=0x12; break;
        case SDLK_o: KEYTBL[7]|=0x21; break;
        case SDLK_l: KEYTBL[7]|=0x0c; break;
        case SDLK_PERIOD: KEYTBL[7]|=0x60; break;
        case SDLK_9: KEYTBL[7]|=0x22; break;
        case SDLK_i: KEYTBL[7]|=0x41; break;
        case SDLK_k: KEYTBL[7]|=0x14; break;
        case SDLK_COMMA: KEYTBL[7]|=0x28; break;
        case SDLK_8: KEYTBL[7]|=0x42; break;
        case SDLK_u: KEYTBL[7]|=0x03; break;
        case SDLK_j: KEYTBL[7]|=0x24; break;
        case SDLK_m: KEYTBL[7]|=0x48; break;
        case SDLK_7: KEYTBL[7]|=0x06; break;
        case SDLK_y: KEYTBL[7]|=0x05; break;
        case SDLK_h: KEYTBL[7]|=0x44; break;
        case SDLK_n: KEYTBL[7]|=0x50; break;
        case SDLK_RETURN: KEYTBL[7]|=0x09; break;
        case SDLK_SPACE: KEYTBL[11]|=0x0c; break;

        case SDLK_LCTRL:  KEYTBL[7]|=0x80; break;
        case SDLK_LSHIFT: KEYTBL[13]|=0x80; break;
        case SDLK_RSHIFT: KEYTBL[14]|=0x80; break;
        case SDLK_QUOTE: KEYTBL[14]|=0x80; break;
        case SDLK_TAB: KEYTBL[11]|=0x80; break;

        case SDLK_DOWN:   KEYTBL[14]|=0x02;break;
        case SDLK_UP:     KEYTBL[14]|=0x08;break;
        case SDLK_LEFT:   KEYTBL[14]|=0x20;break;
        case SDLK_RIGHT:  KEYTBL[14]|=0x04;break;

      }
    }
    if (sdl_event.type == SDL_QUIT) {
       ExitNow=1;
    }
  }

}

#include "Common.h"

